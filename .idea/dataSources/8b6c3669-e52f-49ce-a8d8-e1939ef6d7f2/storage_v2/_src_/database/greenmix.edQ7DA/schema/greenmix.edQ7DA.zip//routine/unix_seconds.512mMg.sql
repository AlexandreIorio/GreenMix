create function unix_seconds() returns bigint
    language sql
as
$$
SELECT EXTRACT(EPOCH FROM NOW())::BIGINT;
$$;

alter function unix_seconds() owner to root;

